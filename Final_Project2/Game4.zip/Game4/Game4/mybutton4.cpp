#include "mybutton4.h"

MyButton4::MyButton4(QWidget *parent, int x, int y, int icon):MyButton(parent, x, y, icon)
{

}
