﻿#ifndef GAME1_H
#define GAME1_H


class Game1
{
public:
    Game1();
};

#endif // GAME1_H
