﻿#ifndef MAINCLASS_H
#define MAINCLASS_H
#include "Login/login.h"
#include "game1/game1.h"
#include "mainWindow/mainwindow.h"

class MainClass{
public:
    MainClass();
};

#endif // MAINCLASS_H
