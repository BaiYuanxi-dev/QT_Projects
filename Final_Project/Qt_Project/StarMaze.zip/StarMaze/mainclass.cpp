﻿#include "mainclass.h"

MainClass::MainClass(){

}
