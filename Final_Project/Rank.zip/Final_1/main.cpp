//#include "mainwindow.h"

#include <QApplication>
#include "EnterGameWidget/entergamewidget.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    //MainWindow w;
    //w.show();
    QString* str;//排名字符串数组，待输�
    str = new QString[8];
    for(int i = 0; i < 8; i ++){
        str[i] = " ZhaoHong  100000";
    }

    str[5] = " nimass l e    ";
    str[3] = "asdsad ascdxin";
    EnterGameWidget *w = new EnterGameWidget(1, str, 8);
    w->show();
    return a.exec();
}
